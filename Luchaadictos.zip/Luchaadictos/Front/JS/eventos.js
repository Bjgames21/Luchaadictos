const params =
new URLSearchParams(
window.location.search
);

const id =
Number(
params.get("id")
);

const eventos =
JSON.parse(
localStorage.getItem(
'eventos'
) || '[]'
);

const evento =
eventos.find(
e => e.id === id
);

if(!evento){

document.body.innerHTML = `

<div style="
padding:50px;
text-align:center;
color:white;
">

<h1>
Evento no encontrado
</h1>

<a
href="../index.html"
style="
color:#facc15;
">

Volver al Inicio

</a>

</div>

`;

throw new Error(
'Evento no encontrado'
);

}

/* TITULOS */

document.getElementById(
'nombreEvento'
).innerText =
evento.nombre;

document.getElementById(
'fechaEvento'
).innerText =
evento.fecha;

/* INFO */

document.getElementById(
'fecha'
).innerText =
evento.fecha;

document.getElementById(
'lugar'
).innerText =
evento.lugar;

document.getElementById(
'precio'
).innerText =
'$' +
evento.precio +
' MXN';

/* IMAGEN */

const banner =
document.querySelector(
'.banner'
);

banner.style.background =

`linear-gradient(
rgba(0,0,0,.45),
rgba(0,0,0,.80)
),
url('${evento.imagen}')`;

banner.style.backgroundSize =
'cover';

banner.style.backgroundPosition =
'center';

/* BOTON COMPRAR */

document.getElementById(
'btnComprar'
).href =

`checkout.html?id=${evento.id}`;