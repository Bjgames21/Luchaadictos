function login(){

const usuario =
document.getElementById(
'usuario'
).value;

const password =
document.getElementById(
'password'
).value;

if(

usuario === 'admin'
&&
password === 'admin123'

){

localStorage.setItem(
'adminLogueado',
'true'
);

window.location.href =
'admin.html';

}
else{

document.getElementById(
'mensaje'
).innerText =
'❌ Usuario o contraseña incorrectos';

}

}