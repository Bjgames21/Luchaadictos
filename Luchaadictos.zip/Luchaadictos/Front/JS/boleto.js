const reserva =
JSON.parse(
localStorage.getItem(
'ultimaReserva'
)
);

if(!reserva){

document.body.innerHTML =
"<h1>No existe boleto</h1>";

throw new Error();

}
if(!reserva.imagen){

reserva.imagen =
'../img/default.jpg';

}

const imagenEvento =
reserva.imagen;

const qrData =
JSON.stringify({

folio:
reserva.folio,

evento:
reserva.evento,

nombre:
reserva.nombre

});

QRCode.toDataURL(
qrData,

function(err,url){

document.getElementById(
'ticketArea'
).innerHTML =

`

<div
class="ticket"
style="
background-image:url('${imagenEvento}');
">

<div class="overlay">

<div class="header">

<div class="logo">

🎟 ACCESO OFICIAL

</div>
function obtenerEstado(estado){

if(estado === 'VALIDADO'){

return '🟢 BOLETO VALIDADO';

}

if(estado === 'CANCELADO'){

return '🔴 BOLETO CANCELADO';

}

return '🟡 BOLETO EMITIDO';

}

<div class="estado">

${obtenerEstado(reserva.estado)}

</div>

</div>

<div class="content">

<div class="info">

<h1>

${reserva.evento}

</h1>

<p>

<b>Nombre:</b>
${reserva.nombre}

</p>

<p>

<b>Folio:</b>
${reserva.folio}

</p>

<p>

<b>Boletos:</b>
${reserva.cantidad}

</p>

<p>

<b>Estado:</b>
${reserva.estado}

</p>

<p>

<b>Total:</b>
$${reserva.total}

</p>

</div>

<div class="qr">

<img
src="${url}"
width="300">

</div>

</div>

<div class="botones">

<button
class="btn imprimir"
onclick="window.print()">

🖨 Imprimir

</button>

<button
class="btn inicio"
onclick="window.location.href='../index.html'">

🏠 Inicio

</button>

</div>

</div>

</div>

`;

}
);