function cargarEventos(){

const eventos =
JSON.parse(
localStorage.getItem(
'eventos'
) || '[]'
);

const contenedor =
document.getElementById(
'eventGrid'
);

if(!contenedor){
return;
}

if(eventos.length === 0){

contenedor.innerHTML = `

<div class="evento-card">

<h3>
No existen eventos registrados
</h3>

<p>
Crea eventos desde el panel Admin.
</p>

</div>

`;

return;

}

let html = '';

eventos
.filter(evento => evento.activo)
.forEach(evento => {

html += `

<div class="evento-card">

<img
src="${evento.imagen}"
alt="${evento.nombre}">

<h3>

${evento.nombre}

</h3>

<p>

📅 ${evento.fecha}

</p>

<p>

📍 ${evento.lugar}

</p>

<p>

🎟 Desde $${evento.precio}

</p>

<a
href="pages/evento.html?id=${evento.id}"
class="btn">

Ver Evento

</a>

</div>

`;

});

contenedor.innerHTML =
html;

}

cargarEventos();