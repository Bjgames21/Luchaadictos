function buscarBoletos(){

const correo =
document.getElementById(
'correo'
).value.trim();

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

const encontrados =
reservas.filter(

r => r.correo
.toLowerCase()
=== correo
.toLowerCase()

);

const resultado =
document.getElementById(
'resultado'
);

if(
encontrados.length === 0
){

resultado.innerHTML = `

<div class="card">

No se encontraron boletos.

</div>

`;

return;

}

let html = '';

encontrados.forEach(

boleto => {

let claseEstado =
'emitido';

if(
boleto.estado ===
'VALIDADO'
){

claseEstado =
'validado';

}

if(
boleto.estado ===
'CANCELADO'
){

claseEstado =
'cancelado';

}

html += `

<div class="card">

<h3>

${boleto.evento}

</h3>

<p>

<b>Folio:</b>
${boleto.folio}

</p>

<p>

<b>Cantidad:</b>
${boleto.cantidad}

</p>

<p>

<b>Total:</b>
$${boleto.total}

</p>

<p
class="
estado
${claseEstado}
">

${boleto.estado}

</p>

<div class="acciones">

<button
onclick="
verBoleto(
'${boleto.folio}'
)
">

Ver Boleto

</button>

</div>

</div>

`;

}

);

resultado.innerHTML =
html;

}

function verBoleto(folio){

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

const boleto =
reservas.find(

r => r.folio === folio

);

localStorage.setItem(
'ultimaReserva',
JSON.stringify(
boleto
)
);

window.location.href =
'../pages/boleto.html';

}