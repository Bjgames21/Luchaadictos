const params =
new URLSearchParams(
window.location.search
);

const id =
Number(
params.get("id")
);

const eventos =
JSON.parse(
localStorage.getItem(
'eventos'
) || '[]'
);

const evento =
eventos.find(
e => e.id === id
);

if(!evento){

document.body.innerHTML = `

<h1 style="
text-align:center;
margin-top:50px;
">

Evento no encontrado

</h1>

`;

throw new Error();

}


document.getElementById(
'eventoNombre'
).innerText =
evento.nombre;

document.getElementById(
'eventoFecha'
).innerText =
"📅 " + evento.fecha;

document.getElementById(
'eventoLugar'
).innerText =
"📍 " + evento.lugar;

document.getElementById(
'eventoPrecio'
).innerText =
"🎟 $" +
evento.precio +
" MXN";

const cantidad =
document.getElementById(
'cantidad'
);

cantidad.addEventListener(
'change',
actualizarTotal
);

function actualizarTotal(){

const total =
evento.precio *
cantidad.value;

document.getElementById(
'total'
).innerText =
"$" + total;

}

actualizarTotal();

document
.getElementById(
'formCompra'
)
.addEventListener(
'submit',
function(e){

e.preventDefault();

const reserva = {

folio:
"LA-" + Date.now(),

eventoId:
evento.id,

evento:
evento.nombre,

imagen:
evento.imagen,

nombre:
document.getElementById(
'nombre'
).value,

correo:
document.getElementById(
'correo'
).value,

telefono:
document.getElementById(
'telefono'
).value,

cantidad:
Number(
cantidad.value
),

total:
evento.precio *
Number(
cantidad.value
),

estado:
"EMITIDO",

validado:false,

fechaCompra:
new Date()
.toLocaleString()

};

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

reservas.push(
reserva
);

localStorage.setItem(
'reservas',
JSON.stringify(
reservas
));

localStorage.setItem(
'ultimaReserva',
JSON.stringify(
reserva
));

window.location.href =
"../pages/boleto.html";

});