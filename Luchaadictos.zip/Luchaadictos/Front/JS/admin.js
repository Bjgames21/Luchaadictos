const COMISION = 10;
function obtenerEventos(){

return JSON.parse(

localStorage.getItem(
'eventos'
)

||

'[]'

);

}

/* NAVEGACION */

function mostrar(id){

document
.querySelectorAll('.seccion')
.forEach(sec=>{

sec.classList.remove(
'activa'
);

});

document
.getElementById(id)
.classList.add(
'activa'
);

}

/* DASHBOARD */

function cargarDashboard(){

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

let ingresos = 0;
let validados = 0;

reservas.forEach(r=>{

ingresos +=
Number(
r.total || 0
);

if(
r.estado ===
'VALIDADO'
){

validados++;

}

});

document
.getElementById(
'vendidos'
).innerText =
reservas.length;

document
.getElementById(
'ingresos'
).innerText =
'$' + ingresos;

document
.getElementById(
'comision'
).innerText =
'$' +
(
reservas.length *
COMISION
);

document
.getElementById(
'validados'
).innerText =
validados;

}

/* COMPRADORES */

function cargarCompradores(){

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

let html = `

<table>

<thead>

<tr>

<th>Folio</th>
<th>Nombre</th>
<th>Evento</th>
<th>Estado</th>
<th>Acciones</th>

</tr>

</thead>

<tbody>

`;

reservas.forEach(

(r,index)=>{

html += `

<tr>

<td>
${r.folio}
</td>

<td>
${r.nombre}
</td>

<td>
${r.evento}
</td>

<td>
${r.estado}
</td>

<td>

<button
class="btn btn-ver"
onclick="
verBoleto(${index})
">

Ver

</button>

<button
class="btn btn-validar"
onclick="
validarBoleto(${index})
">

Validar

</button>

<button
class="btn btn-cancelar"
onclick="
cancelarBoleto(${index})
">

Cancelar

</button>

</td>

</tr>

`;

}

);

html += `
</tbody>
</table>
`;

document
.getElementById(
'tablaCompradores'
).innerHTML =
html;

}

/* VER BOLETO */

function verBoleto(index){

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

localStorage.setItem(
'ultimaReserva',
JSON.stringify(
reservas[index]
)
);

window.open(
'boleto.html',
'_blank'
);

}

/* VALIDAR */

function validarBoleto(index){

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

if(

reservas[index]
.estado ===
'VALIDADO'

){

alert(
'Este boleto ya fue validado'
);

return;

}

reservas[index]
.estado =
'VALIDADO';

reservas[index]
.validado =
true;

localStorage.setItem(

'reservas',

JSON.stringify(
reservas
)

);

cargarDashboard();
cargarCompradores();
cargarEventos();

alert(
'✅ Acceso autorizado'
);

}

/* CANCELAR */

function cancelarBoleto(index){

const reservas =
JSON.parse(
localStorage.getItem(
'reservas'
) || '[]'
);

reservas[index]
.estado =
'CANCELADO';

localStorage.setItem(

'reservas',

JSON.stringify(
reservas
)

);

cargarDashboard();
cargarCompradores();

}

/* INICIO */

cargarDashboard();

cargarCompradores();

/* AUTO REFRESH */

setInterval(()=>{

cargarDashboard();
cargarCompradores();

},3000);

function guardarEvento(){

const eventos =
obtenerEventos();

const nuevoEvento = {

id:
Date.now(),

nombre:
document.getElementById(
'nombreEvento'
).value,

fecha:
document.getElementById(
'fechaEvento'
).value,

precio:
document.getElementById(
'precioEvento'
).value,

lugar:
document.getElementById(
'lugarEvento'
).value,

imagen:
document.getElementById(
'imagenEvento'
).value,

activo:true

};

eventos.push(
nuevoEvento
);

localStorage.setItem(

'eventos',

JSON.stringify(
eventos
)

);

cargarEventos();

}

function cargarEventos(){

const eventos =
obtenerEventos();

let html = `

<table>

<thead>

<tr>

<th>ID</th>
<th>Evento</th>
<th>Fecha</th>
<th>Precio</th>
<th>Estado</th>
<th>Acciones</th>

</tr>

</thead>

<tbody>

`;

eventos.forEach(

evento=>{

html += `

<tr>

<td>${evento.id}</td>

<td>${evento.nombre}</td>

<td>${evento.fecha}</td>

<td>$${evento.precio}</td>

<td>

${evento.activo
?
'🟢 Activo'
:
'🔴 Inactivo'}

</td>

<td>

<button
class="btn btn-validar"
onclick="toggleEvento(${evento.id})">

Activar /
Desactivar

</button>

</td>

</tr>

`;

}

);

html += `
</tbody>
</table>
`;

document
.getElementById(
'tablaEventos'
)
.innerHTML =
html;

}

function toggleEvento(id){

const eventos =
obtenerEventos();

const evento =
eventos.find(

e => e.id === id

);

evento.activo =
!evento.activo;

localStorage.setItem(

'eventos',

JSON.stringify(
eventos
)

);

cargarEventos();

}